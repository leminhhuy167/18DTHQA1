﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practice.Models
{
    public class StudentSearchCriteria
    {
        public string SearchText { get; set; }

        public string ClassName { get; set; }
    }
}
