﻿

namespace Common.Model {
    public class Class {
        public int Id { get; set; }

        public string Name { get; set; }

        public int Year { get; set; }
    }
}
